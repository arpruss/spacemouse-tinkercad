var options = {fps:30, nudgeAngle:22.5, nudgeFirstRepeat:250, nudgeNextRepeat:75,
	nudgeAxis:0.3, nudgeHysteresisRatio:0.67, fly:false, swapYZ:false, navSelection:"3",
	navRotationally:"2", navPositionally:"1", fit:"4", home:"5", fineNudge:"9"}
    