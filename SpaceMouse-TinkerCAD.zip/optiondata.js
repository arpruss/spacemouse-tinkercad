var options = {fps:30, nudgeAngle:22.5, nudgeFirstRepeat:250, nudgeNextRepeat:75,
	nudgeAxis:0.3, nudgeHysteresisRatio:0.67, fly:true, swapYZ:false, navSelection:"3",
	navRotationally:"2", navPositionally:"1", fit:"4", home:"5", fineNudge:"9",
	rotationSpeedMultiplier:"1", requiredDominationAngle:"90", 
	dominance:"none", generic:false,translateX:"0",translateY:"1",translateZ:"2",rotateX:"4",rotateY:"3",rotateZ:"5",
	translateXInvert:false, translateYInvert:false, translateZInvert:true, rotateXInvert:false, rotateYInvert:true, rotateZInvert:false,
    dominant3Plus3Ratio:0.5}
    